local LIB_IDENTIFIER = "LibGroupSocket"
local lib = LibStub(LIB_IDENTIFIER, true) or LibStub:NewLibrary(LIB_IDENTIFIER, 0) 
lib.standalone = true